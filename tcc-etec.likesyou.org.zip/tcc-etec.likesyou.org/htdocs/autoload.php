<?php

class AutoLoadFiles
{
    private array $pastas_acessiveis = [
        __DIR__ . "/app/",
        __DIR__ . "/app/controller/",
        __DIR__ . "/app/database/",
        __DIR__ . "/app/database/repositorios/",
        __DIR__ . "/app/model/",
        __DIR__ . "/app/model/entidades/",
        __DIR__ . "/app/model/objects-values/",
        __DIR__ . "/app/recursos/jwt/",
        __DIR__ . "/app/recursos/jwt/php-jwt/",
        __DIR__ . "/app/recursos/jwt/php-jwt/src/",
        __DIR__ . "/app/service/"
    ];

    public function __construct()
    {
        spl_autoload_register([$this, 'carregarClasse']);
    }

    private function carregarClasse(string $classe): void
    {
        $prefixo = "Firebase\\JWT\\";
        if (strncmp($classe, $prefixo, strlen($prefixo)) === 0) {
            $arquivo = __DIR__ . DIRECTORY_SEPARATOR
                . "app/recursos" . DIRECTORY_SEPARATOR
                . "jwt" . DIRECTORY_SEPARATOR
                . "php-jwt" . DIRECTORY_SEPARATOR
                . "src" . DIRECTORY_SEPARATOR
                . str_replace("\\", DIRECTORY_SEPARATOR, substr($classe, strlen($prefixo)))
                . ".php";

            if (is_file($arquivo)) {
                require_once $arquivo;
                return;
            }
        }

        foreach ($this->pastas_acessiveis as $pasta) {

            $arquivo = $pasta . lcfirst($classe) . ".php";

            if (is_file($arquivo)) {
                require_once $arquivo;
                return;
            }
        }
    }
}