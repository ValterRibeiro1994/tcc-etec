<?php
// Copie como config-banco.php e configure SOMENTE na sua máquina/servidor.
// NÃO faça commit do arquivo com as credenciais reais.
return [
    'host_banco' => 'sql108.infinityfree.com',
    'usuario_banco' => 'if0_42540924',
    'senha_banco' => 'Xa4QN1zAF9',
    'database_banco' => 'if0_42540924_relate_sbc',
];
