/* 
   CRIAR DENÚNCIA - RelateSBC
   - Exige usuário logado (token no localStorage)
   - Carrega as categorias do banco (./categoria/categorias)
   - Mostra a prévia do logradouro (rua, número, complemento - bairro)
   - Envia o formulário para ./denuncia/criar (POST) com o token
*/

(function () {
    'use strict';

   
    const SRC_DO_SCRIPT = document.currentScript ? document.currentScript.src : '';

    // Página para onde o usuário vai depois de enviar (ou cancelar)
    const PAGINA_MURAL = 'denuncia/mural';
    const PAGINA_LOGIN = 'login';

    const TAMANHO_MAXIMO_FOTO = 5 * 1024 * 1024; // 5 MB
    const TIPOS_FOTO = ['image/jpeg', 'image/png'];

    function urlApp(rota) {
        if (SRC_DO_SCRIPT) return new URL('../../../' + rota, SRC_DO_SCRIPT).href;
        return './' + rota;
    }

    // Retorna true quando o aviso foi enviado (nesse caso quem fecha é o mural).
    function avisarModal(tipo) {
        if (window.self === window.top) return false;
        window.parent.postMessage({ tipo: tipo }, window.location.origin);
        return true;
    }

    /* Sessão: só usuário logado cria denúncia */

    // Lê o payload do JWT (a validação de verdade é feita no servidor)
    function lerToken() {
        const token = localStorage.getItem('token');
        if (!token) return null;

        try {
            const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
            const payload = JSON.parse(window.atob(base64));
            if (payload.exp && payload.exp * 1000 < Date.now()) return null; // expirado
            if (!payload.perfil || payload.perfil === 'visitante') return null;
            return token;
        } catch (erro) {
            return null;
        }
    }

    const token = lerToken();
    if (!token) {
        alert('Faça login para registrar uma denúncia.');
        window.top.location.href = urlApp(PAGINA_LOGIN);
        return;
    }

    /* ---------- Elementos ---------- */

    const form        = document.getElementById('form-denuncia');
    const selectCateg = document.getElementById('categoria-denuncia');
    const inputData   = document.getElementById('data-denuncia');
    const inputUf     = document.getElementById('estado-denuncia');
    const inputCidade = document.getElementById('cidade-denuncia');
    const listaCidades = document.getElementById('lista-cidades-denuncia');
    const inputCep    = document.getElementById('cep-denuncia');
    const inputRua    = document.getElementById('rua-denuncia');
    const inputNumero = document.getElementById('numero-denuncia');
    const inputCompl  = document.getElementById('complemento-denuncia');
    const inputBairro = document.getElementById('bairro-denuncia');
    const inputFoto   = document.getElementById('foto-denuncia');
    const fotoInfo    = document.getElementById('foto-info');
    const previa      = document.getElementById('previa-logradouro');
    const caixaMsg    = document.getElementById('mensagem-formulario');
    const btnEnviar   = document.getElementById('btn-enviar');
    const btnCancelar = document.getElementById('btn-cancelar');

    if (!form) return;

    /* ---------- Mensagens ---------- */

    function mostrarMensagem(texto, tipo) {
        caixaMsg.textContent = texto;
        caixaMsg.className = 'alert alert-' + tipo;
        caixaMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function limparMensagem() {
        caixaMsg.textContent = '';
        caixaMsg.className = 'alert d-none';
    }

    /* ---------- Categorias (tb_categoria) ---------- */

    async function carregarCategorias() {
        try {
            const resposta = await fetch(urlApp('categoria/categorias'), {
                method: 'GET',
                credentials: 'same-origin'
            });
            if (!resposta.ok) throw new Error('Falha ao carregar categorias');
            const json = await resposta.json();
            const categorias = Array.isArray(json.dados) ? json.dados : [];

            selectCateg.innerHTML = '';

            if (!json.resposta || categorias.length === 0) {
                selectCateg.innerHTML = '<option value="" selected disabled>Nenhuma categoria disponível</option>';
                return;
            }

            const padrao = document.createElement('option');
            padrao.value = '';
            padrao.selected = true;
            padrao.disabled = true;
            padrao.textContent = 'Selecione uma categoria';
            selectCateg.appendChild(padrao);

            categorias.forEach(function (categoria) {
                const opcao = document.createElement('option');
                opcao.value = categoria.nome_categoria;
                opcao.textContent = categoria.nome_categoria;
                selectCateg.appendChild(opcao);
            });
        } catch (erro) {
            console.error('Não foi possível carregar as categorias.');
            selectCateg.innerHTML = '<option value="" selected disabled>Erro ao carregar categorias</option>';
        }
    }

    /* ---------- Campos: data, UF, CEP ---------- */

    // não permite escolher uma data futura
    const hoje = new Date();
    inputData.max = hoje.getFullYear() + '-' +
        String(hoje.getMonth() + 1).padStart(2, '0') + '-' +
        String(hoje.getDate()).padStart(2, '0');

    /* ---------- Estado e cidade (sugestões do IBGE) ---------- */

const ESTADOS = {
    AC: 'Acre', AL: 'Alagoas', AP: 'Amapá', AM: 'Amazonas', BA: 'Bahia', CE: 'Ceará',
    DF: 'Distrito Federal', ES: 'Espírito Santo', GO: 'Goiás', MA: 'Maranhão',
    MT: 'Mato Grosso', MS: 'Mato Grosso do Sul', MG: 'Minas Gerais', PA: 'Pará',
    PB: 'Paraíba', PR: 'Paraná', PE: 'Pernambuco', PI: 'Piauí', RJ: 'Rio de Janeiro',
    RN: 'Rio Grande do Norte', RS: 'Rio Grande do Sul', RO: 'Rondônia', RR: 'Roraima',
    SC: 'Santa Catarina', SP: 'São Paulo', SE: 'Sergipe', TO: 'Tocantins'
};

function configurarCidadesIBGE(selectEstado, inputCidade, listaCidades) {
    let cidades = [];
    const cache = {};
    let sequenciaCarregamento = 0;

    function semAcento(texto) {
        return String(texto).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
    }

    // monta as opções do estado (mantém a opção vazia no início)
    selectEstado.replaceChildren(new Option('Escolha um estado', '', true, true));
    selectEstado.options[0].disabled = true;
    Object.keys(ESTADOS).forEach(function (uf) {
        selectEstado.add(new Option(uf + ' - ' + ESTADOS[uf], uf));
    });

    function aplicar(nomes) {
        cidades = nomes;
        listaCidades.replaceChildren(...nomes.map(nome => new Option(nome)));
    }

    async function carregar(uf) {
        const requisicao = ++sequenciaCarregamento;
        if (!uf) return aplicar([]);
        if (cache[uf]) return aplicar(cache[uf]);
        try {
            const resposta = await fetch('https://servicodados.ibge.gov.br/api/v1/localidades/estados/' + encodeURIComponent(uf) + '/municipios?orderBy=nome', {
                credentials: 'omit'
            });
            if (!resposta.ok) throw new Error('IBGE indisponível');
            const dados = await resposta.json();
            if (!Array.isArray(dados) || !dados.every(c => c && typeof c.nome === 'string')) {
                throw new Error('Resposta inválida do IBGE');
            }
            const nomes = dados.map(c => c.nome);
            cache[uf] = nomes;
            if (requisicao !== sequenciaCarregamento || selectEstado.value !== uf) return;
            aplicar(nomes);
        } catch (e) {
            if (requisicao === sequenciaCarregamento && selectEstado.value === uf) aplicar([]);
        }
    }

    selectEstado.addEventListener('change', function () {
        inputCidade.value = '';
        carregar(selectEstado.value);
    });

    aplicar([]);

    return {
        // define estado e cidade (usado ao preencher uma denúncia já gravada)
        definir: function (uf, cidade) {
            const sigla = String(uf || '').toUpperCase();
            selectEstado.value = ESTADOS[sigla] ? sigla : '';
            inputCidade.value = cidade || '';
            return carregar(selectEstado.value);
        },

        // devolve o nome oficial da cidade, ou null se não estiver na lista
        validar: function () {
            const digitada = inputCidade.value.trim();
            if (!digitada) return null;
            if (!cidades.length) return digitada; // IBGE fora do ar: aceita texto livre
            const achada = cidades.find(nome => semAcento(nome) === semAcento(digitada));
            if (achada) inputCidade.value = achada;
            return achada || null;
        }
    };
}

const cidadesIBGE = configurarCidadesIBGE(inputUf, inputCidade, listaCidades);

    // CEP: só números, no formato 00000-000
    inputCep.addEventListener('input', function () {
        const numeros = inputCep.value.replace(/\D/g, '').slice(0, 8);
        inputCep.value = numeros.length > 5 ? numeros.slice(0, 5) + '-' + numeros.slice(5) : numeros;
    });

    /* ---------- Prévia do logradouro ---------- */
    function atualizarPrevia() {
        const rua = inputRua.value.trim().replace(/\s+/g, ' ');
        const numero = inputNumero.value.trim();
        const complemento = inputCompl.value.trim().replace(/\s+/g, ' ');
        const bairro = inputBairro.value.trim();

        if (!rua || !numero || !bairro) {
            previa.textContent = 'preencha rua, número e bairro';
            return;
        }

        const partes = [rua, numero];
        if (complemento) partes.push(complemento);
        previa.textContent = partes.join(', ') + ' - ' + bairro;
    }

    [inputRua, inputNumero, inputCompl, inputBairro].forEach(function (campo) {
        campo.addEventListener('input', atualizarPrevia);
    });

    /* ---------- Foto ---------- */

    inputFoto.addEventListener('change', function () {
        const arquivo = inputFoto.files[0];
        if (!arquivo) {
            fotoInfo.textContent = 'JPG ou PNG — tamanho máximo de 5MB';
            return;
        }

        if (TIPOS_FOTO.indexOf(arquivo.type) === -1) {
            mostrarMensagem('A imagem deve ser JPG ou PNG.', 'danger');
            inputFoto.value = '';
            fotoInfo.textContent = 'JPG ou PNG — tamanho máximo de 5MB';
            return;
        }

        if (arquivo.size > TAMANHO_MAXIMO_FOTO) {
            mostrarMensagem('A imagem deve ter no máximo 5MB.', 'danger');
            inputFoto.value = '';
            fotoInfo.textContent = 'JPG ou PNG — tamanho máximo de 5MB';
            return;
        }

        limparMensagem();
        fotoInfo.textContent = arquivo.name;
    });

        /* ---------- Foto obrigatória: aviso e destaque ---------- */

    const caixaFoto = inputFoto.closest('.upload-foto');

    inputFoto.addEventListener('invalid', function () {
        inputFoto.setCustomValidity('Anexe uma foto da ocorrência.');
        caixaFoto.classList.add('invalido');
    });

    inputFoto.addEventListener('change', function () {
        inputFoto.setCustomValidity('');
        caixaFoto.classList.remove('invalido');
    });

    /* ---------- Envio ---------- */

    form.addEventListener('submit', async function (evento) {
        evento.preventDefault();
        limparMensagem();

        if (!cidadesIBGE.validar()) {
    mostrarMensagem('Escolha uma cidade da lista sugerida para o estado selecionado.', 'danger');
    inputCidade.focus();
    return;
}

        const dados = new FormData(form);
        dados.append('metodo', 'POST'); // o roteador exige essa chave

        let enviado = false; // depois de salvar, o botão continua desativado (evita enviar duas vezes)
        btnEnviar.disabled = true;
        const textoOriginal = btnEnviar.textContent;
        btnEnviar.textContent = 'Enviando...';

        try {
            const resposta = await fetch(urlApp('denuncia/criar'), {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Authorization': token },
                body: dados
            });
            if (!resposta.ok) throw new Error('Falha ao registrar denúncia');

            const texto = await resposta.text();
            let json;
            try {
                json = JSON.parse(texto);
            } catch (erroJson) {
                console.error('O servidor retornou uma resposta inválida.');
                mostrarMensagem('Resposta inválida do servidor. Tente novamente.', 'danger');
                return;
            }

            if (!json.resposta) {
                mostrarMensagem(json.mensagem || 'Não foi possível registrar a denúncia.', 'danger');
                return;
            }

            enviado = true;
            mostrarMensagem('Denúncia registrada com sucesso! Redirecionando para o mural...', 'success');
            setTimeout(function () {

                if (avisarModal('denuncia:criada')) return;

                try {
                    if (window.opener && !window.opener.closed) {
                        window.opener.location.reload();
                        window.close();
                        return;
                    }
                } catch (erroOpener) {}
                window.location.href = urlApp(PAGINA_MURAL);
            }, 1500);
        } catch (erro) {
            console.error('Não foi possível enviar a denúncia.');
            mostrarMensagem('Erro de conexão ao enviar a denúncia. Tente novamente.', 'danger');
        } finally {
            if (!enviado) {
                btnEnviar.disabled = false;
                btnEnviar.textContent = textoOriginal;
            }
        }
    });

    btnCancelar.addEventListener('click', function () {
    
        if (avisarModal('denuncia:fechar')) return;
        if (window.opener && !window.opener.closed) {
            window.close();
            return;
        }
        window.location.href = urlApp(PAGINA_MURAL);
    });

    carregarCategorias();
})();
